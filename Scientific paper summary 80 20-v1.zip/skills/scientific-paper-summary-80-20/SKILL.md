---
name: "scientific-paper-summary-80-20"
description: "Summarize a scientific paper (PDF or public link) with the 80/20 rule: weight every chapter mathematically, then return the top 20% of the text, word for word, plus a chapter weight table."
---

# Scientific Paper Summary (80/20, verbatim)

Produce an **extractive** summary of a scientific paper: about 20% of the paper's words, chosen to carry about 80% of its meaning, copied **word for word** from the paper with nothing added. Also return every chapter with its weight.

## Hard rules

1. **Verbatim only.** Every sentence in the summary must appear exactly in the paper. No paraphrase, no connecting words, no ellipses, no brackets, no inserted headings, no "the authors say". The only permitted change is PDF layout cleanup (joining words hyphenated across line breaks, collapsing whitespace, removing page numbers/running headers).
2. **Original order.** Selected sentences keep the order they have in the paper.
3. **Read the whole paper first.** Extract the full text from the PDF or link (every page) before scoring anything. Never score from the abstract alone.
4. **Budget = 20% of body words.** Body = all chapters except References, Acknowledgements, Funding, Conflicts, Author contributions, Data availability, Ethics statements. Do not pad to hit the number and do not exceed it.
5. **Do not invent.** If a figure, table or equation carries a key result, only its verbatim caption/sentence can be used; never describe it.
6. Any text outside the summary block (the chapter table, the metrics line) is reporting, not summary, and is kept clearly separate.

## Step 1: Get the full text

- Local PDF: `pdftotext -layout paper.pdf out.txt` (or PyMuPDF `page.get_text()` for every page). If the text layer is empty, OCR it.
- Public link: if it is an arXiv `abs` link use the matching `pdf` link; otherwise fetch the page or PDF with WebFetch (or the shell if the network allows) and extract the text. If only part of a page was returned, keep fetching until the whole paper is read, and say so if you could not.
- Use two-column-aware extraction if sentences interleave. Remove running headers/footers.

## Step 2: Split into chapters and sentences

- A **chapter** is a top-level section heading ("1 Introduction", "II. Methods", "Abstract", "Conclusion"). Merge subsections into their parent chapter. Text before the first heading is "Front matter".
- Split sentences at `. ! ?` followed by a capital letter or digit, protecting `et al.`, `Fig.`, `Eq.`, `e.g.`, `i.e.`, `vs.`.
- Drop from candidacy: sentences under 6 words, figure/table captions starting with `Fig`/`Table`, and anything inside excluded chapters (they still get a row in the table with weight 0).

## Step 3: The weighting equations

Terms are lowercase alphabetic words (3+ letters) that are not stopwords. Let `idf(t) = ln(1 + N/df(t))` where N is the number of sentences and df counts sentences containing t. `D` is the TF-IDF vector of the whole paper and `K = 40` is the set of the 40 highest-mass terms of D (the paper's key concepts).

### 3a. Chapter weight

For each chapter `s`, compute four signals and min-max normalize each to [0, 1] across chapters (marked with a hat):

- `C_s` = cosine(TF-IDF vector of chapter s, D)  (how central it is to the whole paper)
- `R_s` = role prior from the table below (what kind of chapter it is)
- `Q_s` = (claim cues + 0.5 * numeric tokens) / words in s  (how much evidence and claim language per word)
- `L_s` = sqrt(words in s)  (size, with diminishing returns)

```
W_s = 0.30*C_hat + 0.35*R + 0.20*Q_hat + 0.15*L_hat
weight_s (%) = 100 * W_s / sum_over_all_chapters(W)
```

Role priors R: Abstract 1.0, Conclusion 0.9, Results/Experiments/Evaluation 0.85, Discussion/Limitations 0.7, Introduction/Background 0.6, Methods/Approach/Model 0.55, Related Work 0.3, Appendix 0.15, References/Acknowledgements/Funding/etc. 0.0, any unmatched heading 0.5.

Claim cues: "we show/propose/find/introduce/demonstrate/present/conclude", "results show/indicate/suggest", "outperform", "significant", "novel", "in this paper", "our method/approach/model/results/findings", "improv*", "achieve*".

### 3b. Sentence score

For sentence `i` in chapter `s`:

```
S_i = (W_s / max_s W_s) * ( 0.50*c_i + 0.25*k_i + 0.15*q_i + 0.10*p_i )
```

- `c_i` = cosine(TF-IDF of sentence i, D)
- `k_i` = share of the sentence's distinct terms that are in the key-concept set K
- `q_i` = min(1, (claim cues + 0.5 * numbers) / 3)
- `p_i` = 1 if first or last sentence of its chapter, else 0

So a sentence's score is its own information value, scaled by how important its chapter is. Important chapters win more of the 20%.

### 3c. Selection (the 20%)

Greedy with a redundancy penalty (MMR, lambda = 0.3): repeatedly pick the sentence with the highest `S_i - 0.3 * maxJaccard(i, already chosen) * S_i` that still fits the word budget; stop when nothing fits. Then sort the chosen sentences back into paper order.

### 3d. Check the 80%

`coverage = (TF-IDF mass of key concepts K that appear in the summary) / (total mass of K)`. Report it. If coverage is below 0.80, say so honestly in the metrics line; do not add text to raise it.

## Step 4: Verify before answering

Assert every summary sentence is a substring of the whitespace-normalized source text. If any is not, remove or fix it. Confirm summary words are at most 20% of body words.

## Step 5: Output format

**Summary** (one block of verbatim sentences, original order, nothing else inside it)

**Chapters and weights**

| # | Chapter (as titled in the paper) | Words | Weight % | Sentences kept |
|---|---|---|---|---|

Weights sum to 100%. List every chapter, including excluded ones at 0%.

**Metrics:** body words, summary words (and % of body), key-concept coverage, extraction source.

## Reference implementation (Python, standard library only)

Adapt as needed. Run with `python3 -I script.py paper.txt`.

```python
import re, math, sys
from collections import Counter

STOP = set("the a an of and or to in on for with by is are was were be been this that these those as at from it its we our can which not but also than then such into over under between using used use may more most their there have has had will would could should do does did if when while where who whom whose how what why about each other both any all some".split())
PRIORS = [
 (r'abstract|summary', 1.0), (r'conclusion|concluding', 0.9),
 (r'result|finding|experiment|evaluation', 0.85), (r'discussion|limitation', 0.7),
 (r'introduction|overview|background', 0.6),
 (r'method|approach|material|design|framework|proposed|model', 0.55),
 (r'related work|literature|prior work', 0.3), (r'appendix|supplement', 0.15),
 (r'reference|bibliograph|acknowledg|funding|conflict|contribution|availability|ethic', 0.0)]
CUES = re.compile(r'\b(we (show|propose|find|introduce|demonstrate|present|develop|report|conclude)|results? (show|indicate|suggest)|outperform|significant|novel|contribution|in this paper|our (method|approach|model|results|findings)|demonstrate|achieve|improv|conclude)', re.I)
HEAD = re.compile(r'^(?:(\d{1,2})\.?|([IVX]{1,5})\.)\s+([A-Z][^\n]{2,80})$|^(Abstract|Introduction|Conclusions?|References|Acknowledg\w+|Appendix[^\n]{0,40})$', re.I)

def toks(s): return [w for w in re.findall(r"[a-z][a-z\-]{2,}", s.lower()) if w not in STOP]
def prior(t):
    for pat, p in PRIORS:
        if re.search(pat, t, re.I): return p
    return 0.5
def split_sents(text):
    t = re.sub(r'\b(et al|Fig|Figs|Eq|Eqs|e\.g|i\.e|vs|cf|Tab|Sec|No)\.', lambda m: m.group(0).replace('.', '<D>'), text)
    return [s.replace('<D>', '.').strip() for s in re.split(r'(?<=[.!?])\s+(?=[A-Z0-9("\[])', t) if s.strip()]
def norm(text): return re.sub(r'-\n(?=[a-z])', '', text)   # layout cleanup only
def sections(text):
    secs, cur = [], ['Front matter', []]
    for line in norm(text).split('\n'):
        l = line.strip()
        if l and HEAD.match(l) and not re.match(r'^\d+\.\d+', l):
            secs.append(cur); cur = [l, []]
        else: cur[1].append(l)
    secs.append(cur)
    return [(t, ' '.join(b)) for t, b in secs if ' '.join(b).strip()]
def cos(a, b):
    num = sum(v * b.get(k, 0) for k, v in a.items())
    den = math.sqrt(sum(v*v for v in a.values())) * math.sqrt(sum(v*v for v in b.values()))
    return num / den if den else 0.0
def mm(xs):
    lo, hi = min(xs), max(xs); return [(x - lo) / (hi - lo) if hi > lo else 0.5 for x in xs]

def run(text, ratio=0.20, K=40, lam=0.3):
    secs = sections(text)
    S = [(si, s) for si, (t, b) in enumerate(secs) for s in split_sents(b)]
    N = len(S); df = Counter()
    for _, s in S: df.update(set(toks(s)))
    idf = {t: math.log(1 + N / d) for t, d in df.items()}
    vec = lambda ws: {t: c * idf.get(t, 0) for t, c in Counter(ws).items()}
    docv = Counter()
    for _, s in S:
        for t, v in vec(toks(s)).items(): docv[t] += v
    topK = [t for t, _ in docv.most_common(K)]; topset = set(topK)
    rows = []
    for si, (t, b) in enumerate(secs):
        ws = [w for i, s in S if i == si for w in toks(s)]
        raw = len(b.split())
        Q = (len(CUES.findall(b)) + 0.5 * len(re.findall(r'\d+(?:\.\d+)?%?', b))) / max(raw, 1)
        rows.append(dict(i=si, title=t, words=raw, C=cos(vec(ws), docv), R=prior(t), Q=Q, L=math.sqrt(raw)))
    for k in ('C', 'Q', 'L'):
        for r, v in zip(rows, mm([r[k] for r in rows])): r[k + 'n'] = v
    for r in rows: r['W'] = 0.30*r['Cn'] + 0.35*r['R'] + 0.20*r['Qn'] + 0.15*r['Ln']
    tot = sum(r['W'] for r in rows); mx = max(r['W'] for r in rows)
    for r in rows: r['share'] = r['W'] / tot; r['Wh'] = r['W'] / mx
    body = sum(r['words'] for r in rows if r['R'] > 0); budget = round(ratio * body)
    cand = []
    for idx, (si, s) in enumerate(S):
        n = len(s.split())
        if rows[si]['R'] == 0 or n < 6 or re.match(r'^(Fig|Figure|Table)\b', s): continue
        w = toks(s); sec_idx = [j for j, (a, _) in enumerate(S) if a == si]
        p = 1.0 if idx in (sec_idx[0], sec_idx[-1]) else 0.0
        k = len(set(w) & topset) / max(len(set(w)), 1)
        q = min(1.0, (len(CUES.findall(s)) + 0.5 * len(re.findall(r'\d+(?:\.\d+)?%?', s))) / 3)
        cand.append(dict(idx=idx, si=si, s=s, n=n, w=set(w),
                         raw=rows[si]['Wh'] * (0.5*cos(vec(w), docv) + 0.25*k + 0.15*q + 0.10*p)))
    chosen, used = [], 0
    while True:
        best, bs = None, -1
        for c in cand:
            if c in chosen or used + c['n'] > budget: continue
            red = max([len(c['w'] & d['w']) / max(len(c['w'] | d['w']), 1) for d in chosen] or [0])
            sc = c['raw'] * (1 - lam * red)
            if sc > bs: best, bs = c, sc
        if not best: break
        chosen.append(best); used += best['n']
    chosen.sort(key=lambda c: c['idx'])
    flat = re.sub(r'\s+', ' ', norm(text))
    assert all(re.sub(r'\s+', ' ', c['s']) in flat for c in chosen), 'non-verbatim sentence'
    sw = set(w for c in chosen for w in c['w'])
    cov = sum(docv[t] for t in topK if t in sw) / sum(docv[t] for t in topK)
    for r in rows:
        r['sel'] = sum(1 for c in chosen if c['si'] == r['i'])
    return ' '.join(c['s'] for c in chosen), rows, dict(body=body, budget=budget, used=used, pct=used/body, coverage=cov)
```

If the heading detector mis-splits a particular paper (e.g. unnumbered headings), fix the chapter boundaries by hand-checking the extracted text, then rerun. The equations stay the same.